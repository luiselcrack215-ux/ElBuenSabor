namespace ElBuenSaborAndroid;

public partial class MainPage : ContentPage
{
    private readonly (string Name, int Price, string Image)[] foods =
    {
        ("Hamburguesa", 120, "burger.svg"),
        ("Pizza", 180, "pizza.svg"),
        ("Pollo frito", 150, "chicken.svg"),
        ("Tacos", 100, "tacos.svg"),
        ("Papas fritas", 60, "fries.svg"),
        ("Ensalada", 80, "salad.svg")
    };

    private readonly (string Name, int Price)[] drinks =
    {
        ("Coca Cola", 35),
        ("Jugo", 30),
        ("Agua", 20),
        ("Fresco natural", 25)
    };

    private int total;
    private readonly List<string> order = new();

    public MainPage()
    {
        InitializeComponent();
        FoodPicker.ItemsSource = foods.Select(f => $"{f.Name} - C${f.Price}").ToList();
        DrinkPicker.ItemsSource = drinks.Select(d => $"{d.Name} - C${d.Price}").ToList();
        FoodPicker.SelectedIndex = 0;
        DrinkPicker.SelectedIndex = 0;
    }

    private void OnFoodChanged(object? sender, EventArgs e)
    {
        if (FoodPicker.SelectedIndex < 0) return;
        var food = foods[FoodPicker.SelectedIndex];
        FoodName.Text = food.Name;
        FoodPrice.Text = $"C${food.Price}";
        FoodImage.Source = food.Image;
    }

    private async void OnAddOrder(object? sender, EventArgs e)
    {
        if (FoodPicker.SelectedIndex < 0 || DrinkPicker.SelectedIndex < 0)
        {
            await DisplayAlert("Atención", "Seleccione una comida y una bebida.", "Aceptar");
            return;
        }

        var food = foods[FoodPicker.SelectedIndex];
        var drink = drinks[DrinkPicker.SelectedIndex];
        int subtotal = food.Price + drink.Price;
        total += subtotal;
        order.Add($"{food.Name} C${food.Price} + {drink.Name} C${drink.Price} = C${subtotal}");
        OrderText.Text = string.Join(Environment.NewLine, order);
        TotalLabel.Text = $"Total: C${total}";
    }

    private async void OnShowTotal(object? sender, EventArgs e)
    {
        await DisplayAlert("Cuenta del restaurante", $"El total de su pedido es C${total}", "Aceptar");
    }

    private void OnClearOrder(object? sender, EventArgs e)
    {
        order.Clear();
        total = 0;
        OrderText.Text = "Todavía no hay productos.";
        TotalLabel.Text = "Total: C$0";
    }
}
