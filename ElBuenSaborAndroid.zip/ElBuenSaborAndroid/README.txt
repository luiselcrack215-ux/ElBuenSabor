RESTAURANTE EL BUEN SABOR - PROYECTO ANDROID

Este proyecto es la adaptación Android del menú de restaurante.
Usa .NET MAUI (C#), con controles equivalentes para Android:
- Picker: selección de comida y bebida (similar a ComboBox).
- Image: fotografía/imagen del platillo (similar a PictureBox).
- Lista de texto del pedido: muestra los artículos agregados.

REQUISITOS
1. Windows 10/11 o macOS con Visual Studio 2022 actualizado.
2. Instalar la carga de trabajo ".NET Multi-platform App UI development".
3. Tener instalado Android SDK y aceptar sus licencias.

ABRIR
1. Descomprime ElBuenSaborAndroid.zip.
2. Abre ElBuenSaborAndroid.csproj en Visual Studio.
3. Selecciona un emulador Android o conecta un teléfono con depuración USB.
4. Ejecuta para probar.

GENERAR APK
En una terminal dentro de la carpeta del proyecto, ejecuta:
  dotnet workload install maui-android
  dotnet publish -f net8.0-android -c Release

El APK se genera dentro de:
  bin/Release/net8.0-android/publish/

NOTA
Este entorno de creación no tiene instalado .NET MAUI ni Android SDK,
por lo que aquí se entrega el proyecto fuente preparado para compilar,
no un APK ya compilado. Para generar el archivo APK se necesita completar
la compilación en un equipo con los requisitos anteriores.
